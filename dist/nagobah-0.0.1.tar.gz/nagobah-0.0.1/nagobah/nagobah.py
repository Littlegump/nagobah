#!/usr/bin/env python
# _*_ coding: utf-8 _*_

def main():
    """ print test"""
    print "hello"

